package mx.iteso.cuentas;

import mx.iteso.cuentas.Cuenta;
import mx.iteso.cuentas.CuentaAhorro;
import mx.iteso.cuentas.CuentaCorriente;
import mx.iteso.cuentas.CuentaCorrienteConInteres;

public class TestCuenta {

    public static void main(String[] args) {
        Cuenta[] cuentas = new Cuenta[6];

        CuentaAhorro ahorro1 = new CuentaAhorro("Victoria", "281104", 750, 2, 99);
        CuentaAhorro ahorro2 = new CuentaAhorro("Diego", "558960", 950, 3, 100);
        
        CuentaCorriente corriente1 = new CuentaCorriente("Francisco", "079060", 16809, 10, 5, 8);
        CuentaCorriente corriente2 = new CuentaCorriente("Juan Pablo", "555798", 9360, 10, 3, 11);
        
        CuentaCorrienteConInteres intereses1 = new CuentaCorrienteConInteres("Rodrigo", "506090", 42000, 12, 8, 25, 10000);
        CuentaCorrienteConInteres intereses2 = new CuentaCorrienteConInteres("Diana", "569034", 85980, 15, 6, 20, 30000);

        ahorro1.deposito(900);
        ahorro1.deposito(1500);
        
        ahorro2.deposito(2600);
        ahorro2.deposito(4000);

        
        corriente1.deposito(52000);
        corriente1.deposito(700);
        
        corriente2.deposito(80);
        corriente2.deposito(900);

        
        intereses1.deposito(600);
        intereses1.deposito(500);
        
        intereses2.deposito(400);
        intereses2.deposito(2500);

        
        ahorro1.retiro(700);
        ahorro1.retiro(550);
        
        ahorro2.retiro(650);
        ahorro2.retiro(900);

        
        corriente1.retiro(1000);
        corriente1.retiro(600);
        
        corriente2.retiro(900);
        corriente2.retiro(400);

        
        intereses1.retiro(600);
        intereses1.retiro(1000);
        
        intereses2.retiro(200);
        intereses2.retiro(4000);

        Cuenta[] cuentas1 = {ahorro1, ahorro2, corriente1, corriente2, intereses1, intereses2};

        for (Cuenta cuenta : cuentas1) {
            cuenta.comisiones();
            cuenta.intereses();
        }

        for (Cuenta cuenta : cuentas1) {
            System.out.printf("\n \n" + cuenta.toString());
        }
    }
}