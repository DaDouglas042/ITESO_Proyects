package mx.iteso.cuentas;

public class CuentaAhorro extends Cuenta {
    private double cuotaDeMantenimiento;

    
    //COnstructor
    public CuentaAhorro(String nombre, String cuenta, double saldo, double tasaDeInteres, double cuotaDeMantenimiento) {
        super(nombre, cuenta, saldo, tasaDeInteres);
        this.cuotaDeMantenimiento = cuotaDeMantenimiento;
    }

	public double getCuotaMantenimiento() {
		return cuotaDeMantenimiento;
	}

	public void setCuotaMantenimiento(double cuotaDeMantenimiento) {
		this.cuotaDeMantenimiento = (cuotaDeMantenimiento >= 0) ? cuotaDeMantenimiento : 0.0;
	}
    public double intereses() {
        // Calcular intereses para la cuenta de ahorro
        double intereses = saldo * tasaDeInteres / 12; // Dividir la tasa anual entre 12 para el mes actual
        saldo += intereses; // Aumentar el saldo con los intereses ganados
        return intereses;
    	
    }

    public double comisiones() {
        // Calcular comisiones para la cuenta de ahorro
        saldo -= cuotaDeMantenimiento; // Restar la cuota de mantenimiento del saldo
        return cuotaDeMantenimiento;
    }

    public String toString() {
        return super.toString() + "\nCuota de Mantenimiento: " + cuotaDeMantenimiento;
    }
}