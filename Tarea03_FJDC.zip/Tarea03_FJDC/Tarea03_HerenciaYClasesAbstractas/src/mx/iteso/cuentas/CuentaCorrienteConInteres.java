package mx.iteso.cuentas;

public class CuentaCorrienteConInteres extends CuentaCorriente {
    private double saldoMinimo;

    public CuentaCorrienteConInteres(String nombre, String cuenta, double saldo, double tasaDeInteres, int transExentas, double importePorTransaccion, double saldoMinimo) {
        super(nombre, cuenta, saldo, tasaDeInteres, transExentas, importePorTransaccion);
        this.saldoMinimo = saldoMinimo;
    }
    
    
	public double getSaldoMinimo() {
		return saldoMinimo;
	}

	public void setSaldoMinimo(double saldoMinimo) {
		this.saldoMinimo = saldoMinimo;
	}
	

    public double intereses() {
    	   double diferenciaSaldo = saldo - saldoMinimo;
    	    if (diferenciaSaldo > 0) {
    	        double intereses = diferenciaSaldo * tasaDeInteres / 12; // Dividir la tasa anual entre 12 para el mes actual
    	        saldo += intereses; // Aumentar el saldo con los intereses ganados
    	        return intereses;
    	    } else {
    	        return 0.0; // No se pagan intereses si el saldo es menor que el saldo mínimo
    	    }
    }
    
    public String toString() {
        return super.toString() + "\nSaldo Mínimo: " + saldoMinimo;
    }
}