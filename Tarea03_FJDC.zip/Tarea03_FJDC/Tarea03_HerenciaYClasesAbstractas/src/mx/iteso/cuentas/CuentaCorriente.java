package mx.iteso.cuentas;

public class CuentaCorriente extends Cuenta {
    private int transExentas;
    private double importePorTransaccion;
    private int contador = 0;

    
    //Constructor
    public CuentaCorriente(String nombre, String cuenta, double saldo, double tasaDeInteres, int transExentas, double importePorTransaccion) {
        super(nombre, cuenta, saldo, tasaDeInteres);
        this.transExentas = transExentas;
        this.importePorTransaccion = importePorTransaccion;
    }

    
    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }

    public double getMontoPorOperacion() {
        return importePorTransaccion;
    }

    public void setMontoPorOperacion(double montoPorOperacion) {
        this.importePorTransaccion = montoPorOperacion;
    }

    public int getOperacionesExentas() {
        return transExentas;
    }

    public void setOperacionesExentas(int operacionesExentas) {
        this.transExentas = operacionesExentas;
    }

    
    public void deposito(double cantidad) {
        if (cantidad > 0) {
            setSaldo(getSaldo() + cantidad);
            contador++;
            System.out.printf("Operación exitosa\n");
        } else System.out.printf("Operación no exitosa\n");
    }

    
    public void retiro(double cantidad) {
        if (cantidad > 0) {
            setSaldo(getSaldo() - cantidad);
            contador++;
            System.out.printf("Operación exitosa\n");
        } else System.out.printf("Operación no exitosa\n");
    }
    
    public double intereses() {
        // Calcular intereses para la cuenta corriente
        double intereses = saldo * tasaDeInteres / 12; // Dividir la tasa anual entre 12 para el mes actual
        saldo += intereses; // Aumentar el saldo con los intereses ganados
        return intereses;
    }

    public double comisiones() {
        // Calcular comisiones para la cuenta corriente
        int transaccionesRealizadas = getContador(); // Utiliza el contador que lleva el registro de transacciones
        int transaccionesExentas = transExentas;
        if (transaccionesRealizadas > transaccionesExentas) {
            double comisiones = (transaccionesRealizadas - transaccionesExentas) * importePorTransaccion;
            setSaldo(getSaldo() - comisiones); // Restar las comisiones del saldo
            return comisiones;
        } else {
            return 0.0; // No se aplican comisiones
        }
    }

    public String toString() {
        return super.toString() + "\nTransacciones Exentas: " + transExentas + "\nImporte por Transacción: " + importePorTransaccion;
    }
}