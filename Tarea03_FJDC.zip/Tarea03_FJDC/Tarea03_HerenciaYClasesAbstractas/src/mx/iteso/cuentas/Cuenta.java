package mx.iteso.cuentas;

public abstract class Cuenta {
	
    protected String nombre;
    protected String cuenta;
    protected double saldo;
    protected double tasaDeInteres;

 
    //Constructor
    public Cuenta(String nombre, String cuenta, double saldo, double tasaDeInteres) {
        this.nombre = nombre;
        this.cuenta = cuenta;
        this.saldo = saldo;
        this.tasaDeInteres = tasaDeInteres;
    }

    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = (nombre != null) ? nombre : "NombreD";
    }

    public String getCuenta() {
        return cuenta;
    }

    public void setCuenta(String cuenta) {
        this.cuenta = (cuenta != null) ? cuenta : "000000";
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = (saldo >= 0) ? saldo : 0.0;
    }

    public double getTasaDeInteres() {
        return tasaDeInteres;
    }

    public void setTasaDeInteres(double tasaDeInteres) {
        this.tasaDeInteres = (tasaDeInteres >= 0) ? tasaDeInteres : 0.0;
    }

    public void deposito(double cantidad) {
        if (cantidad > 0) {
            this.saldo += cantidad;
            System.out.printf("Operación exitosa\n");
        } else System.out.printf("Operación no exitosa\n");
    }

    public void retiro(double cantidad) {
        if (cantidad > 0 && this.saldo - cantidad >= 0) {
            this.saldo -= cantidad;
            System.out.printf("Operación exitosa\n");
        } else System.out.printf("Operación no exitosa\n");
    }
    
    
    public abstract double intereses();
    public abstract double comisiones();

    public String toString() {
        return "Nombre: " + nombre + "\nCuenta: " + cuenta + "\nSaldo: " + saldo + "\nTasa de Interés: " + tasaDeInteres;
    }
}


